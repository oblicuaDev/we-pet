<div class="stepBox step-1">
    <h2 class="title"><?=$wp->findUiWord(62)?></h2>
    <p><?=$wp->findUiWord(63)?></p>
    <button type="button" onclick="tour.next();activeNextStep();">Siguiente</button>
</div>
<div class="stepBox step-2">
    <h2 class="title"><?=$wp->findUiWord(64)?></h2>
    <p><?=$wp->findUiWord(65)?></p>
    <button type="button" onclick="tour.next();activeNextStep();">Siguiente</button>
</div>
<div class="stepBox step-3">
    <h2 class="title"><?=$wp->findUiWord(66)?></h2>
    <p><?=$wp->findUiWord(67)?></p>
    <button type="button" onclick="tour.next();activeNextStep();">Siguiente</button>
</div>
<div class="stepBox step-4">
    <h2 class="title"><?=$wp->findUiWord(69)?></h2>
    <p><?=$wp->findUiWord(68)?></p>
    <button type="button" onclick="tour.next();activeNextStep();">Siguiente</button>
</div>
<div class="stepBox step-5">
    <h2 class="title"><?=$wp->findUiWord(70)?></h2>
    <p><?=$wp->findUiWord(71)?></p>
    <button type="button" onclick="tour.next();activeNextStep();">Siguiente</button>
</div>
<div class="stepBox step-6">
    <h2 class="title"><?=$wp->findUiWord(72)?></h2>
    <p><?=$wp->findUiWord(73)?></p>
    <button type="button" onclick="tour.next();activeNextStep();">Siguiente</button>
</div>
<div class="stepBox step-7">
    <h2 class="title"><?=$wp->findUiWord(248)?></h2>
    <p><?=$wp->findUiWord(250)?></p>
    <button type="button" onclick="tour.next();activeNextStep();">Siguiente</button>
</div>
<div class="stepBox step-8">
    <h2 class="title"><?=$wp->findUiWord(76)?></h2>
    <p><?=$wp->findUiWord(77)?></p>
    <button type="button" onclick="tour.next();activeNextStep();">Siguiente</button>
</div>