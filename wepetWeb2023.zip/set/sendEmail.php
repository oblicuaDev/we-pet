<?php
include '../includes/config.php';
 $sended = $wp->egoiEmail($_GET['email'],"¡Tu cupón está listo!", "7", $_GET['mergeTags']);
 echo json_encode($sended);